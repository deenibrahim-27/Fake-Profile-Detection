"""
Application Configuration
Loads settings from environment variables with safe development defaults.
"""

import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-antigravity-mca-fake-profile-secret-2026')
    DATABASE_PATH = os.environ.get(
        'DATABASE_PATH',
        os.path.join(os.path.dirname(__file__), 'database', 'fake_profile.db')
    )
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() in ['true', '1']
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max payload
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'


import pandas as pd
import joblib

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

# Load datasets
train = pd.read_csv("data/train.csv")
test = pd.read_csv("data/test.csv")

# Separate input features and target labels
X_train = train.drop(columns=["fake"])
y_train = train["fake"]

X_test = test.drop(columns=["fake"])
y_test = test["fake"]

# Convert text values into numeric values
X_train = pd.get_dummies(X_train)
X_test = pd.get_dummies(X_test)

# Keep training and testing columns consistent
X_train, X_test = X_train.align(
    X_test,
    join="outer",
    axis=1,
    fill_value=0
)

# Fill missing values
X_train = X_train.fillna(0)
X_test = X_test.fillna(0)

# Create the model
model = RandomForestClassifier(
    n_estimators=200,
    random_state=42,
    class_weight="balanced"
)

# Train the model
model.fit(X_train, y_train)

# Predict test results
predictions = model.predict(X_test)

# Evaluate model
print("\nMODEL EVALUATION")
print("----------------")
print("Accuracy:", round(
    accuracy_score(y_test, predictions) * 100, 2
), "%")

print("\nClassification Report:")
print(classification_report(y_test, predictions))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, predictions))

# Save model and feature columns
joblib.dump(model, "fake_profile_model.pkl")
joblib.dump(list(X_train.columns), "feature_columns.pkl")

print("\nModel saved successfully!")

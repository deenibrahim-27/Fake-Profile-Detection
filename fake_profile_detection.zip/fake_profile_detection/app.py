
from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd
import joblib
import os

app = Flask(__name__)
app.secret_key = "fake_profile_detection_demo_key"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.join(BASE_DIR, "fake_profile_model.pkl")
COLUMNS_PATH = os.path.join(BASE_DIR, "feature_columns.pkl")

model = joblib.load(MODEL_PATH)
feature_columns = joblib.load(COLUMNS_PATH)


@app.route("/")
def home():
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        # Demo login only
        if username == "admin" and password == "admin123":
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("dashboard"))

        return render_template(
            "login.html",
            error="Invalid username or password"
        )

    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        return redirect(url_for("login"))

    return render_template("dashboard.html")


@app.route(
    "/detect/<platform>",
    methods=["GET", "POST"],
    endpoint="detect_profile"
)
def detect_profile(platform):
    if not session.get("logged_in"):
        return redirect(url_for("login"))

    allowed_platforms = ["instagram", "facebook", "linkedin"]

    if platform not in allowed_platforms:
        return "Unsupported platform", 404

    # Current trained model is for the Instagram dataset only.
    if platform != "instagram":
        return (
            f"{platform.title()} detection is not connected yet. "
            "A separate dataset and model are required.",
            501
        )

    if request.method == "GET":
        return render_template(
            "detect.html",
            platform=platform
        )

    try:
        profile = {
            "username": request.form.get("username", "").strip(),
            "profile pic": int(request.form.get("profile pic", 0)),
            "nums/length username": float(
                request.form.get("nums/length username", 0)
            ),
            "fullname words": int(
                request.form.get("fullname words", 0)
            ),
            "nums/length fullname": float(
                request.form.get("nums/length fullname", 0)
            ),
            "name==username": int(
                request.form.get("name==username", 0)
            ),
            "description length": int(
                request.form.get("description length", 0)
            ),
            "external URL": int(
                request.form.get("external URL", 0)
            ),
            "private": int(
                request.form.get("private", 0)
            ),
            "#posts": int(
                request.form.get("#posts", 0)
            ),
            "#followers": int(
                request.form.get("#followers", 0)
            ),
            "#follows": int(
                request.form.get("#follows", 0)
            )
        }

        if not profile["username"]:
            return render_template(
                "detect.html",
                platform=platform,
                error="Please enter a username."
            )

        # Keep username for display; use only dataset features for prediction.
        model_profile = {
            key: value
            for key, value in profile.items()
            if key != "username"
        }

        profile_df = pd.DataFrame([model_profile])
        profile_df = pd.get_dummies(profile_df)

        profile_df = profile_df.reindex(
            columns=feature_columns,
            fill_value=0
        )

        predicted_class = int(model.predict(profile_df)[0])
        probabilities = model.predict_proba(profile_df)[0]

        class_positions = {
            int(label): index
            for index, label in enumerate(model.classes_)
        }

        genuine_score = (
            float(probabilities[class_positions[0]]) * 100
            if 0 in class_positions else 0.0
        )

        fake_score = (
            float(probabilities[class_positions[1]]) * 100
            if 1 in class_positions else 0.0
        )

        # Confirm that your training dataset uses 0 = Genuine, 1 = Fake.
        if predicted_class == 0:
            prediction = "Likely Genuine"
        else:
            prediction = "Potentially Fake"

        # Basic observations about the submitted profile.
        # These are NOT proof that the account is fake.
        observations = []

        if profile["profile pic"] == 0:
            observations.append(
                "No profile picture was indicated in the submitted data."
            )

        if profile["description length"] == 0:
            observations.append(
                "The submitted profile has an empty bio."
            )

        if profile["external URL"] == 0:
            observations.append(
                "No external website link was indicated."
            )

        if profile["#posts"] == 0:
            observations.append(
                "The submitted profile has zero posts."
            )

        if profile["#followers"] < profile["#follows"]:
            observations.append(
                "The following count is higher than the follower count."
            )

        if not observations:
            observations.append(
                "No basic profile observations were triggered."
            )

        return render_template(
            "result.html",
            prediction=prediction,
            genuine_score=genuine_score,
            fake_score=fake_score,
            profile=profile,
            platform=platform,
            observations=observations
        )

    except (ValueError, TypeError, KeyError) as error:
        return render_template(
            "detect.html",
            platform=platform,
            error=(
                "Please enter valid values in all fields. "
                f"Details: {error}"
            )
        )


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)

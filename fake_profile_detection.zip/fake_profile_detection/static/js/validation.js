/**
 * Client-side validation and dynamic feature calculation
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Instagram Real-Time Helper
    const igUsername = document.getElementById('ig_username');
    const igDigitsRatio = document.getElementById('ig_digits_ratio');
    if (igUsername && igDigitsRatio) {
        igUsername.addEventListener('input', function () {
            const val = this.value.trim();
            if (val.length === 0) {
                igDigitsRatio.innerText = "0.0%";
                return;
            }
            const digits = (val.match(/\d/g) || []).length;
            const ratio = ((digits / val.length) * 100).toFixed(1);
            igDigitsRatio.innerText = `${ratio}% (${digits} digits / ${val.length} chars)`;
            if (ratio > 30) {
                igDigitsRatio.className = "text-danger fw-bold";
            } else {
                igDigitsRatio.className = "text-success";
            }
        });
    }

    // 2. Follower to Following Ratio Helper
    const igFollowers = document.getElementById('ig_followers');
    const igFollows = document.getElementById('ig_follows');
    const igRatioDisplay = document.getElementById('ig_ratio_display');
    function updateIgRatio() {
        if (!igFollowers || !igFollows || !igRatioDisplay) return;
        const followers = parseInt(igFollowers.value) || 0;
        const follows = parseInt(igFollows.value) || 0;
        if (follows === 0) {
            igRatioDisplay.innerText = `${followers}:1`;
            return;
        }
        const ratio = (followers / follows).toFixed(2);
        igRatioDisplay.innerText = `${ratio} (Followers / Following)`;
        if (follows > 500 && ratio < 0.1) {
            igRatioDisplay.className = "text-danger fw-bold";
        } else {
            igRatioDisplay.className = "text-info";
        }
    }
    if (igFollowers && igFollows) {
        igFollowers.addEventListener('input', updateIgRatio);
        igFollows.addEventListener('input', updateIgRatio);
    }

    // 3. Facebook Friend Request vs Friends Ratio
    const fbFriends = document.getElementById('fb_friends');
    const fbRequests = document.getElementById('fb_requests');
    const fbRatioDisplay = document.getElementById('fb_ratio_display');
    function updateFbRatio() {
        if (!fbFriends || !fbRequests || !fbRatioDisplay) return;
        const friends = parseInt(fbFriends.value) || 0;
        const reqs = parseInt(fbRequests.value) || 0;
        if (reqs > 200 && friends < 50) {
            fbRatioDisplay.innerText = "Warning: Outbound request anomaly detected";
            fbRatioDisplay.className = "text-danger fw-bold";
        } else {
            fbRatioDisplay.innerText = "Normal Request Pattern";
            fbRatioDisplay.className = "text-muted";
        }
    }
    if (fbFriends && fbRequests) {
        fbFriends.addEventListener('input', updateFbRatio);
        fbRequests.addEventListener('input', updateFbRatio);
    }
});

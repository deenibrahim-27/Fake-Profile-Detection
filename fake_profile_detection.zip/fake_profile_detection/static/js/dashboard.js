/**
 * Dashboard Analytics with Chart.js
 * Renders live visual analytics for Genuine vs Fake distribution and Platform comparisons.
 */

document.addEventListener('DOMContentLoaded', function () {
    const statusChartCanvas = document.getElementById('statusDoughnutChart');
    const platformChartCanvas = document.getElementById('platformBarChart');

    if (!statusChartCanvas || !platformChartCanvas) {
        return;
    }

    fetch('/api/dashboard-stats')
        .then(response => response.json())
        .then(data => {
            renderStatusDoughnut(statusChartCanvas, data);
            renderPlatformBar(platformChartCanvas, data);
        })
        .catch(err => {
            console.error("Failed to load dashboard metrics:", err);
        });
});

function renderStatusDoughnut(canvas, data) {
    const genuine = data.genuine_count || 0;
    const fake = data.fake_count || 0;
    const inconclusive = data.inconclusive_count || 0;
    const hasData = (genuine + fake + inconclusive) > 0;

    new Chart(canvas.getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: hasData ? ['Likely Genuine', 'Likely Fake', 'Inconclusive'] : ['No Data Recorded'],
            datasets: [{
                data: hasData ? [genuine, fake, inconclusive] : [1],
                backgroundColor: hasData 
                    ? ['#10b981', '#ef4444', '#f59e0b']
                    : ['#334155'],
                borderWidth: 2,
                borderColor: '#111827'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#94a3b8',
                        font: { family: 'Inter', size: 12 },
                        padding: 16
                    }
                },
                tooltip: {
                    enabled: hasData
                }
            },
            cutout: '72%'
        }
    });
}

function renderPlatformBar(canvas, data) {
    const platforms = data.platform_counts || { instagram: 0, facebook: 0, linkedin: 0 };

    new Chart(canvas.getContext('2d'), {
        type: 'bar',
        data: {
            labels: ['Instagram', 'Facebook', 'LinkedIn'],
            datasets: [{
                label: 'Profiles Evaluated',
                data: [
                    platforms.instagram || 0,
                    platforms.facebook || 0,
                    platforms.linkedin || 0
                ],
                backgroundColor: [
                    'rgba(225, 48, 108, 0.85)',
                    'rgba(24, 119, 242, 0.85)',
                    'rgba(10, 102, 194, 0.85)'
                ],
                borderColor: [
                    '#e1306c',
                    '#1877f2',
                    '#0a66c2'
                ],
                borderWidth: 1.5,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        color: '#64748b',
                        font: { family: 'Inter' }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    }
                },
                x: {
                    ticks: {
                        color: '#94a3b8',
                        font: { family: 'Inter', weight: '500' }
                    },
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

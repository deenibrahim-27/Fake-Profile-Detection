# Facebook Fake Profile Detection Dataset Guide

## Kaggle Dataset Information
- **Recommended Kaggle Datasets**:
  1. *Facebook Fake Profile Detection* by mishra5001 / subhajeetdas
     - **URL**: https://www.kaggle.com/datasets/mishra5001/facebook-fake-profile-detection
  2. *Social Network Fake Account Detection*
     - **Kaggle Search Query**: `facebook fake profile detection`
- **File Name**: `facebook_profiles.csv`

## Dataset Schema
| Column Name | Type | Description |
|---|---|---|
| `name_length` | Integer | Character length of Facebook profile name |
| `friends_count` | Integer | Number of friends on Facebook |
| `friend_requests_sent` | Integer | Estimated friend requests sent |
| `posts_count` | Integer | Number of timeline posts |
| `likes_received` | Integer | Likes received across posts |
| `account_age_days` | Integer | Account age in days since creation |
| `profile_picture_present`| Binary (0, 1) | Whether profile picture is present |
| `status_updates_recent` | Integer | Number of status updates in past 30 days |
| `mobile_number_linked` | Binary (0, 1) | Whether mobile phone verification is linked |
| `is_fake` | Binary (0, 1) | Target label: `0` = Genuine, `1` = Fake |

## Preprocessing Requirements
- Handle missing values in numerical columns.
- Standardize skewed features such as `likes_received` and `friends_count`.
- Drop duplicate entries.
- Stratified 80/20 train/test split.

# LinkedIn Fake Profile Detection Dataset Guide

## Kaggle Dataset Information
- **Recommended Kaggle Datasets**:
  1. *LinkedIn Fake Profiles & Social Network Fake Account Detection* by arashnic / ashishkumarjaiswal
     - **URL**: https://www.kaggle.com/datasets/arashnic/social-network-fake-account-detection
  2. *LinkedIn User Profiles Dataset for Anomaly & Fake Detection*
     - **Kaggle Search Query**: `linkedin fake profile detection`
- **File Name**: `linkedin_profiles.csv`

## Dataset Schema
| Column Name | Type | Description |
|---|---|---|
| `headline_length` | Integer | Character length of the professional headline |
| `connections_count` | Integer | Connection count (0 to 1000+) |
| `experience_entries_count` | Integer | Number of listed job roles/experience positions |
| `education_entries_count` | Integer | Number of listed schools/degrees |
| `skills_count` | Integer | Number of skills endorsed or added |
| `profile_picture_present` | Binary (0, 1) | Professional photo uploaded (1 = Yes, 0 = No) |
| `summary_length` | Integer | Character length of profile 'About' summary |
| `recommendations_count` | Integer | Number of received recommendations |
| `has_current_company` | Binary (0, 1) | Currently employed company listed |
| `is_fake` | Binary (0, 1) | Target label: `0` = Genuine, `1` = Fake |

## Preprocessing Requirements
- Handle missing values (e.g., empty summaries or recommendations).
- Scale numerical distributions (connections, skills).
- Remove duplicates and validate integrity.
- Stratified 80/20 train/test split.

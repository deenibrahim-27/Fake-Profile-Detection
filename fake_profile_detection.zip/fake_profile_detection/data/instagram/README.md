# Instagram Fake Profile Detection Dataset Guide

## Kaggle Dataset Information
- **Recommended Kaggle Datasets**:
  1. *Instagram Fake Spammer Genuine Accounts* by free-spammer-detection / rohanrao
     - **URL**: https://www.kaggle.com/datasets/free-spammer-detection/instagram-fake-spammer-genuine-accounts
  2. *Instagram Fake and Automated Account Detection*
     - **Kaggle Search Query**: `instagram fake spammer accounts`
- **File Name**: `instagram_profiles.csv`

## Dataset Schema
| Column Name | Type | Description |
|---|---|---|
| `profile_pic` | Binary (0, 1) | Whether profile picture is present |
| `nums_length_username` | Float (0.0 - 1.0) | Ratio of digits to username length |
| `fullname_words` | Integer | Word count in display full name |
| `nums_length_fullname` | Float (0.0 - 1.0) | Ratio of digits to full name length |
| `name_equals_username` | Binary (0, 1) | 1 if full name is identical to username, 0 otherwise |
| `description_length` | Integer | Bio / description character count |
| `external_url` | Binary (0, 1) | 1 if profile has bio link |
| `private` | Binary (0, 1) | 1 if account is private, 0 if public |
| `posts` | Integer | Total posts count |
| `followers` | Integer | Total follower count |
| `follows` | Integer | Total following count |
| `is_fake` | Binary (0, 1) | Target label: `0` = Genuine, `1` = Fake |

## Preprocessing Requirements
- Handle missing values in numerical columns using median imputation.
- Handle outliers and extreme follower/following ratios.
- Drop duplicate entries.
- Stratified 80/20 train/test split.

"""
Unit tests for Prediction Service inference and explainability
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from ml.prediction_service import predict_profile


class TestPredictionService(unittest.TestCase):

    def test_instagram_likely_fake(self):
        # High digit ratio, 0 avatar, mass follows, 0 posts
        input_data = {
            'username': 'spammer_8839201',
            'fullname': 'spammer_8839201',
            'bio': '',
            'profile_pic': 0,
            'external_url': 1,
            'private': 0,
            'posts': 0,
            'followers': 5,
            'follows': 4500
        }
        res = predict_profile('instagram', input_data)
        self.assertIn(res['status'], ['LIKELY FAKE', 'INCONCLUSIVE'])
        self.assertGreater(res['fake_probability'], 50.0)
        self.assertIn('top_factors', res)
        self.assertIn('disclaimer', res)

    def test_instagram_likely_genuine(self):
        # Clean username, avatar present, balanced ratio, active posts
        input_data = {
            'username': 'clara_walker',
            'fullname': 'Clara Walker',
            'bio': 'Travel enthusiast & landscape photographer based in Seattle.',
            'profile_pic': 1,
            'external_url': 0,
            'private': 0,
            'posts': 65,
            'followers': 850,
            'follows': 400
        }
        res = predict_profile('instagram', input_data)
        self.assertEqual(res['status'], 'LIKELY GENUINE')
        self.assertGreater(res['genuine_probability'], 60.0)
        self.assertIn('narrative_bullets', res)

    def test_facebook_prediction(self):
        input_data = {
            'profile_name': 'Michael Scott',
            'friends_count': 350,
            'friend_requests_sent': 15,
            'posts_count': 55,
            'likes_received': 400,
            'account_age_days': 1200,
            'profile_picture_present': 1,
            'status_updates_recent': 6,
            'mobile_number_linked': 1
        }
        res = predict_profile('facebook', input_data)
        self.assertEqual(res['status'], 'LIKELY GENUINE')
        self.assertTrue(0.0 <= res['confidence_score'] <= 100.0)

    def test_linkedin_prediction(self):
        input_data = {
            'profile_name': 'Dr. Robert Oppen',
            'headline': 'Principal Research Scientist at Quantum Labs',
            'summary': 'Over 15 years leading cross-functional quantum algorithms research.',
            'connections_count': 500,
            'experience_entries_count': 5,
            'education_entries_count': 2,
            'skills_count': 30,
            'recommendations_count': 4,
            'profile_picture_present': 1,
            'has_current_company': 1
        }
        res = predict_profile('linkedin', input_data)
        self.assertEqual(res['status'], 'LIKELY GENUINE')


if __name__ == '__main__':
    unittest.main()

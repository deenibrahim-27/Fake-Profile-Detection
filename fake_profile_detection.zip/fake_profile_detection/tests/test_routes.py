"""
Integration tests for Flask application routes and session management
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import app
from database.db import init_db


class TestFlaskRoutes(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        app.config['TESTING'] = True
        app.config['SECRET_KEY'] = 'test-secret'
        with app.app_context():
            init_db()

    def setUp(self):
        self.client = app.test_client()

    def test_public_routes(self):
        # Homepage
        r1 = self.client.get('/')
        self.assertEqual(r1.status_code, 200)
        self.assertIn(b'Fake Profile Detection', r1.data)

        # About page
        r2 = self.client.get('/about')
        self.assertEqual(r2.status_code, 200)
        self.assertIn(b'Master of Computer Applications', r2.data)

        # Datasets page
        r3 = self.client.get('/datasets')
        self.assertEqual(r3.status_code, 200)
        self.assertIn(b'Dataset Sources & Schemas', r3.data)

    def test_auth_workflow(self):
        import uuid
        test_user = f"user_{uuid.uuid4().hex[:6]}"
        test_email = f"{test_user}@example.com"
        pwd = "securepassword123"

        # Register
        reg_resp = self.client.post('/register', data={
            'username': test_user,
            'email': test_email,
            'password': pwd,
            'confirm_password': pwd
        }, follow_redirects=True)
        self.assertEqual(reg_resp.status_code, 200)
        self.assertIn(b'Registration successful', reg_resp.data)

        # Login
        login_resp = self.client.post('/login', data={
            'username_or_email': test_user,
            'password': pwd
        }, follow_redirects=True)
        self.assertEqual(login_resp.status_code, 200)
        self.assertIn(b'Welcome back', login_resp.data)

        # Access Dashboard (Authenticated)
        dash_resp = self.client.get('/dashboard')
        self.assertEqual(dash_resp.status_code, 200)

        # Submit an Instagram detection form
        pred_resp = self.client.post('/detect/instagram', data={
            'username': 'test_account_99',
            'fullname': 'Test Account',
            'bio': 'Demo test profile',
            'profile_pic': '1',
            'external_url': '0',
            'private': '0',
            'posts': '15',
            'followers': '400',
            'follows': '200'
        }, follow_redirects=True)
        self.assertEqual(pred_resp.status_code, 200)
        self.assertIn(b'Instagram Analysis Result', pred_resp.data)

        # Check History
        hist_resp = self.client.get('/history')
        self.assertEqual(hist_resp.status_code, 200)
        self.assertIn(b'@test_account_99', hist_resp.data)

        # Check CSV Export
        csv_resp = self.client.get('/export/csv')
        self.assertEqual(csv_resp.status_code, 200)
        self.assertEqual(csv_resp.content_type, 'text/csv; charset=utf-8')

        # Logout
        logout_resp = self.client.get('/logout', follow_redirects=True)
        self.assertEqual(logout_resp.status_code, 200)
        self.assertIn(b'logged out', logout_resp.data)


if __name__ == '__main__':
    unittest.main()

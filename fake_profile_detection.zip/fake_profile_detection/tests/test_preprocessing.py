"""
Unit tests for data preprocessing and feature extraction
"""

import unittest
import pandas as pd
import numpy as np

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from ml.data_preprocessing import (
    clean_dataframe,
    extract_instagram_features_from_raw,
    extract_facebook_features_from_raw,
    extract_linkedin_features_from_raw,
    build_preprocessor,
    get_platform_features
)


class TestPreprocessing(unittest.TestCase):

    def test_clean_dataframe_removes_duplicates(self):
        raw_data = pd.DataFrame({
            'profile_pic': [1, 1, 0],
            'nums_length_username': [0.1, 0.1, 0.5],
            'fullname_words': [2, 2, 1],
            'nums_length_fullname': [0.0, 0.0, 0.2],
            'name_equals_username': [0, 0, 1],
            'description_length': [50, 50, 10],
            'external_url': [1, 1, 0],
            'private': [0, 0, 1],
            'posts': [20, 20, 2],
            'followers': [500, 500, 30],
            'follows': [300, 300, 1200],
            'is_fake': [0, 0, 1]
        })
        cleaned = clean_dataframe(raw_data, 'instagram')
        self.assertEqual(len(cleaned), 2, "Duplicate rows should be removed")

    def test_extract_instagram_features(self):
        user_input = {
            'username': 'bot_123456',
            'fullname': 'Bot Name',
            'bio': 'Follow for follow!',
            'profile_pic': 0,
            'external_url': 1,
            'private': 0,
            'posts': 2,
            'followers': 10,
            'follows': 2000
        }
        df = extract_instagram_features_from_raw(user_input)
        self.assertEqual(len(df), 1)
        # 'bot_123456' has 6 digits out of 10 chars = 0.6
        self.assertAlmostEqual(df['nums_length_username'].iloc[0], 0.6, places=2)
        self.assertEqual(df['profile_pic'].iloc[0], 0)
        self.assertEqual(df['fullname_words'].iloc[0], 2)

    def test_extract_facebook_features(self):
        user_input = {
            'profile_name': 'John Doe',
            'friends_count': 150,
            'friend_requests_sent': 400,
            'posts_count': 10,
            'likes_received': 50,
            'account_age_days': 20,
            'profile_picture_present': 0,
            'status_updates_recent': 1,
            'mobile_number_linked': 0
        }
        df = extract_facebook_features_from_raw(user_input)
        self.assertEqual(len(df), 1)
        self.assertEqual(df['name_length'].iloc[0], 8)
        self.assertEqual(df['friends_count'].iloc[0], 150)
        self.assertEqual(df['mobile_number_linked'].iloc[0], 0)

    def test_extract_linkedin_features(self):
        user_input = {
            'profile_name': 'Alice Smith',
            'headline': 'Software Engineer',
            'summary': 'Passionate about coding',
            'connections_count': 500,
            'experience_entries_count': 4,
            'education_entries_count': 2,
            'skills_count': 25,
            'recommendations_count': 3,
            'profile_picture_present': 1,
            'has_current_company': 1
        }
        df = extract_linkedin_features_from_raw(user_input)
        self.assertEqual(len(df), 1)
        self.assertEqual(df['connections_count'].iloc[0], 500)
        self.assertEqual(df['experience_entries_count'].iloc[0], 4)
        self.assertEqual(df['has_current_company'].iloc[0], 1)


if __name__ == '__main__':
    unittest.main()

# Fake Profile Detection for Instagram, Facebook, and LinkedIn Using Machine Learning

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Flask](https://img.shields.io/badge/Framework-Flask%203-green.svg)](https://flask.palletsprojects.com/)
[![Scikit-Learn](https://img.shields.io/badge/ML-Scikit--Learn-orange.svg)](https://scikit-learn.org/)
[![Bootstrap](https://img.shields.io/badge/Frontend-Bootstrap%205-purple.svg)](https://getbootstrap.com/)
[![License](https://img.shields.io/badge/Project-MCA%20Mini%20Project-informational.svg)]()

An academic, end-to-end Machine Learning web application designed for forensic detection of automated spambots, fraudulent clone accounts, and synthetic personas across three major social media networks: **Instagram**, **Facebook**, and **LinkedIn**.

---

## 1. Project Architecture & Features

- **Multi-Platform Forensic Modules**: Distinct, platform-specialized forms, validation rules, feature engineering, and inference pipelines for Instagram, Facebook, and LinkedIn.
- **Leakage-Free ML Pipeline**: Integrated scikit-learn `Pipeline` and `ColumnTransformer` (median imputers, standard scalers, and estimators) trained using Stratified 5-Fold Cross-Validation.
- **Model Comparison Engine**: Automatically compares Logistic Regression, Decision Tree, Random Forest, and Gradient Boosting before selecting the optimal model based on held-out validation F1-score and ROC-AUC.
- **Tri-State Verdict & Calibrated Probabilities**: Displays **LIKELY GENUINE**, **LIKELY FAKE**, or an explicit **INCONCLUSIVE** verdict for borderline ambiguous profiles (between 42% and 58% fake probability).
- **Explainable AI (XAI)**: Generates automated narrative findings and key risk indicators (e.g., username digit entropy, friend request velocity anomalies, career gap signals).
- **Forensic PDF & CSV Exports**: Instant download of official academic-grade PDF reports (using ReportLab) and CSV prediction histories.
- **Secure Authentication**: Salted and hashed passwords using PBKDF2:SHA256, session management, and protected dashboard routes.
- **Interactive Analytics Dashboard**: Visualizations powered by Chart.js displaying real-time database records and model validation metrics.

---

## 2. Directory Structure

```text
fake_profile_detection/
│
├── app.py                      # Flask main entrypoint & web routes
├── config.py                   # App configuration & environment settings
├── requirements.txt            # Python dependencies
├── Procfile                    # Render / Heroku process declaration
├── .env.example                # Sample environment file
├── README.md                   # Complete documentation
│
├── data/                       # Dataset directories
│   ├── instagram/              # instagram_profiles.csv & README.md
│   ├── facebook/               # facebook_profiles.csv & README.md
│   └── linkedin/               # linkedin_profiles.csv & README.md
│
├── models/                     # Serialized pipelines & metrics
│   ├── instagram/              # model.joblib & metrics.json
│   ├── facebook/               # model.joblib & metrics.json
│   └── linkedin/               # model.joblib & metrics.json
│
├── ml/                         # ML Pipeline source code
│   ├── __init__.py
│   ├── data_preprocessing.py   # Cleaning, imputers, scalers, schema transformers
│   ├── evaluate_models.py      # Cross-validation, model comparison & training engine
│   ├── train_instagram.py      # Standalone Instagram trainer
│   ├── train_facebook.py       # Standalone Facebook trainer
│   ├── train_linkedin.py       # Standalone LinkedIn trainer
│   ├── prediction_service.py   # Cached inference, probabilities & explainability
│   ├── dataset_generator.py    # Empirical benchmark dataset generator
│   └── pdf_report.py           # ReportLab PDF report generator
│
├── database/                   # Database layer
│   ├── __init__.py
│   ├── schema.sql              # SQLite schema DDL
│   ├── db.py                   # Context-managed connection pool & CRUD operations
│   └── fake_profile.db         # SQLite database file
│
├── templates/                  # Jinja2 HTML5 templates
│   ├── base.html               # Master layout with responsive navbar & footer
│   ├── index.html              # Landing page with hero & platform cards
│   ├── register.html           # User registration
│   ├── login.html              # User login
│   ├── dashboard.html          # Analytics dashboard with Chart.js
│   ├── instagram_form.html     # Instagram detection form
│   ├── facebook_form.html      # Facebook detection form
│   ├── linkedin_form.html      # LinkedIn detection form
│   ├── result.html             # Detailed prediction & explainability view
│   ├── history.html            # Searchable & filterable history table
│   ├── about.html              # MCA project overview & methodology
│   └── datasets.html           # Kaggle datasets documentation
│
├── static/                     # Static frontend assets
│   ├── css/
│   │   └── style.css           # Glassmorphism design system & responsive styling
│   ├── js/
│   │   ├── dashboard.js        # Dynamic Chart.js scripts
│   │   └── validation.js       # Client-side validation & live counters
│   └── images/
│
└── tests/                      # Automated test suite
    ├── test_preprocessing.py   # Unit tests for preprocessing & extractors
    ├── test_prediction.py      # Unit tests for predictions & XAI
    └── test_routes.py          # Integration tests for Flask routes & auth
```

---

## 3. Kaggle Datasets & Schemas

### A. Instagram Fake & Genuine Profiles
- **Kaggle Source**: [Instagram Fake Spammer Genuine Accounts](https://www.kaggle.com/datasets/free-spammer-detection/instagram-fake-spammer-genuine-accounts)
- **Search Terms**: `instagram fake spammer accounts`
- **File**: `data/instagram/instagram_profiles.csv`
- **Features (11)**: `profile_pic`, `nums_length_username`, `fullname_words`, `nums_length_fullname`, `name_equals_username`, `description_length`, `external_url`, `private`, `posts`, `followers`, `follows`. Target: `is_fake`.

### B. Facebook Fake Profile Detection
- **Kaggle Source**: [Facebook Fake Profile Detection](https://www.kaggle.com/datasets/mishra5001/facebook-fake-profile-detection)
- **Search Terms**: `facebook fake profile detection`
- **File**: `data/facebook/facebook_profiles.csv`
- **Features (9)**: `name_length`, `friends_count`, `friend_requests_sent`, `posts_count`, `likes_received`, `account_age_days`, `profile_picture_present`, `status_updates_recent`, `mobile_number_linked`. Target: `is_fake`.

### C. LinkedIn Fake Profiles
- **Kaggle Source**: [Social Network Fake Account Detection (LinkedIn)](https://www.kaggle.com/datasets/arashnic/social-network-fake-account-detection)
- **Search Terms**: `linkedin fake profile detection`
- **File**: `data/linkedin/linkedin_profiles.csv`
- **Features (9)**: `headline_length`, `connections_count`, `experience_entries_count`, `education_entries_count`, `skills_count`, `profile_picture_present`, `summary_length`, `recommendations_count`, `has_current_company`. Target: `is_fake`.

---

## 4. Local Setup & Execution Guide

### Step 1: Clone or Navigate to the Project
```powershell
cd C:\Users\gayathiri\.gemini\antigravity-ide\scratch\fake_profile_detection
```

### Step 2: Create & Activate Virtual Environment
```powershell
# Create virtual environment
python -m venv venv

# Activate on Windows PowerShell
.\venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Generate Benchmark Datasets (or Place Kaggle CSVs)
To seed the empirical benchmark datasets matching Kaggle schemas:
```powershell
python ml/dataset_generator.py
```
*(Alternatively, place your downloaded Kaggle CSVs into `data/instagram/`, `data/facebook/`, and `data/linkedin/`)*

### Step 5: Train and Evaluate Models
Execute 5-Fold cross-validation, algorithm comparison, and test evaluation:
```powershell
python ml/evaluate_models.py
```
*Or train individually:*
```powershell
python ml/train_instagram.py
python ml/train_facebook.py
python ml/train_linkedin.py
```

### Step 6: Run Automated Tests
```powershell
python -m unittest discover tests
```

### Step 7: Launch Web Application
```powershell
python app.py
```
Open your browser and navigate to: **`http://127.0.0.1:5000`**

---

## 5. Deployment Guide (Render)

1. Push your repository to **GitHub**.
2. Sign in to **[Render.com](https://render.com/)** and select **New Web Service**.
3. Connect your GitHub repository.
4. Set the following build and run configurations:
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt && python ml/evaluate_models.py`
   - **Start Command**: `gunicorn app:app`
5. Under **Environment Variables**, add:
   - `SECRET_KEY`: `<generate-a-random-hex-string>`
   - `FLASK_DEBUG`: `False`
   - `PYTHON_VERSION`: `3.11.0` or `3.12.0`
6. Click **Deploy Web Service**.

---

## 6. Ethical Notice & Disclaimer

This system is an academic research demonstration for educational and decision-support purposes. Predictions are probabilistic assessments derived from statistical pattern recognition. They do not constitute forensic proof, defamatory conclusions, or official platform action.

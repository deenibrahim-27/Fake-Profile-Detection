
import pandas as pd
import joblib

# Load the trained model and feature names
model = joblib.load("fake_profile_model.pkl")
feature_columns = joblib.load("feature_columns.pkl")

# Enter sample Instagram profile details
profile = {
    "profile pic": 1,
    "nums/length username": 0.10,
    "fullname words": 2,
    "nums/length fullname": 0.0,
    "name==username": 0,
    "description length": 60,
    "external URL": 1,
    "private": 0,
    "#posts": 45,
    "#followers": 1200,
    "#follows": 600
}

# Convert the profile into a DataFrame
profile_df = pd.DataFrame([profile])

# Match the exact features used during training
profile_df = profile_df.reindex(
    columns=feature_columns,
    fill_value=0
)

# Predict the profile
prediction = int(model.predict(profile_df)[0])
probabilities = model.predict_proba(profile_df)[0]

# Display the result
if prediction == 0:
    print("\nPrediction: LIKELY GENUINE")
else:
    print("\nPrediction: POTENTIALLY FAKE")

print("Predicted class:", prediction)
print("Model confidence for predicted class:",
      round(float(max(probabilities)) * 100, 2), "%")

print("\nProbability for each class:")
for label, probability in zip(
    model.classes_, probabilities
):
    name = "Genuine" if label == 0 else "Fake"
    print(f"{name}: {probability * 100:.2f}%")

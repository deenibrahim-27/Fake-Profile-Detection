
import pandas as pd
import joblib

# Load saved model and training feature columns
model = joblib.load("fake_profile_model.pkl")
feature_columns = joblib.load("feature_columns.pkl")

# Three fictional profile examples
profiles = [
    {
        "Profile": "Profile A",
        "profile pic": 1,
        "nums/length username": 0.10,
        "fullname words": 2,
        "nums/length fullname": 0.0,
        "name==username": 0,
        "description length": 60,
        "external URL": 1,
        "private": 0,
        "#posts": 45,
        "#followers": 1200,
        "#follows": 600
    },
    {
        "Profile": "Profile B",
        "profile pic": 0,
        "nums/length username": 0.50,
        "fullname words": 1,
        "nums/length fullname": 0.50,
        "name==username": 1,
        "description length": 0,
        "external URL": 0,
        "private": 0,
        "#posts": 0,
        "#followers": 8,
        "#follows": 900
    },
    {
        "Profile": "Profile C",
        "profile pic": 1,
        "nums/length username": 0.20,
        "fullname words": 3,
        "nums/length fullname": 0.0,
        "name==username": 0,
        "description length": 100,
        "external URL": 0,
        "private": 1,
        "#posts": 150,
        "#followers": 500,
        "#follows": 450
    }
]

for item in profiles:
    name = item["Profile"]

    # Prepare input features
    profile_df = pd.DataFrame([
        {k: v for k, v in item.items() if k != "Profile"}
    ])

    # Apply the same encoding and column structure
    profile_df = pd.get_dummies(profile_df)
    profile_df = profile_df.reindex(
        columns=feature_columns,
        fill_value=0
    )

    # Predict
    prediction = model.predict(profile_df)[0]
    probabilities = model.predict_proba(profile_df)[0]

    print("\n---------------------------")
    print(name)
    print("Predicted class:", prediction)

    if prediction == 0:
        print("Result: LIKELY GENUINE")
    else:
        print("Result: POTENTIALLY FAKE")

    for label, probability in zip(
        model.classes_, probabilities
    ):
        label_name = (
            "Genuine" if label == 0 else "Fake"
        )
        print(
            f"{label_name} score: "
            f"{probability * 100:.2f}%"
        )

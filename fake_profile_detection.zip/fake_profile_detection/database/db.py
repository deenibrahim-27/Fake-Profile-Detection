"""
Database Management Module
Handles SQLite connection pooling, parameterized queries, schema initialization,
user authentication operations, and prediction logging.
"""

import os
import sqlite3
import json
from werkzeug.security import generate_password_hash, check_password_hash

DATABASE_PATH = os.path.join(os.path.dirname(__file__), 'fake_profile.db')


from contextlib import contextmanager

@contextmanager
def get_db():
    """Yields an active SQLite database connection and guarantees closure."""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    """Initializes SQLite tables from schema.sql."""
    schema_path = os.path.join(os.path.dirname(__file__), 'schema.sql')
    with open(schema_path, 'r') as f:
        schema_sql = f.read()

    with get_db() as conn:
        conn.executescript(schema_sql)
        conn.commit()
    print(f"[+] Initialized SQLite database at {DATABASE_PATH}")


# ================= User Operations =================

def register_user(username: str, email: str, password: str) -> tuple[bool, str]:
    """Registers a new user with secure password hashing."""
    username = username.strip()
    email = email.strip().lower()

    if not username or not email or not password:
        return False, "All fields are required."
    if len(password) < 6:
        return False, "Password must be at least 6 characters long."

    pwd_hash = generate_password_hash(password, method='pbkdf2:sha256')

    try:
        with get_db() as conn:
            conn.execute(
                "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
                (username, email, pwd_hash)
            )
            conn.commit()
            return True, "Registration successful. You can now log in."
    except sqlite3.IntegrityError as e:
        err_msg = str(e).lower()
        if 'username' in err_msg:
            return False, "Username is already taken."
        elif 'email' in err_msg:
            return False, "Email address is already registered."
        return False, "A user with those details already exists."


def authenticate_user(username_or_email: str, password: str):
    """Authenticates a user by username/email and password."""
    target = username_or_email.strip().lower()
    with get_db() as conn:
        cursor = conn.execute(
            "SELECT * FROM users WHERE LOWER(username) = ? OR LOWER(email) = ?",
            (target, target)
        )
        user = cursor.fetchone()

        if user and check_password_hash(user['password_hash'], password):
            return dict(user)
    return None


def get_user_by_id(user_id: int):
    """Fetches user details by primary key."""
    with get_db() as conn:
        cursor = conn.execute("SELECT id, username, email, created_at FROM users WHERE id = ?", (user_id,))
        row = cursor.fetchone()
        return dict(row) if row else None


# ================= Prediction History Operations =================

def save_prediction(user_id: int, platform: str, identifier: str, status: str,
                    confidence: float, fake_prob: float, genuine_prob: float,
                    input_features: dict, explanation: dict) -> int:
    """Persists a profile prediction report to SQLite."""
    with get_db() as conn:
        cursor = conn.execute(
            """
            INSERT INTO predictions 
            (user_id, platform, profile_identifier, status, confidence_score, fake_probability, genuine_probability, input_features_json, explanation_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                platform.lower(),
                identifier,
                status,
                confidence,
                fake_prob,
                genuine_prob,
                json.dumps(input_features),
                json.dumps(explanation)
            )
        )
        conn.commit()
        return cursor.lastrowid


def get_user_predictions(user_id: int, platform: str = None, status: str = None):
    """Retrieves filtered predictions for a user."""
    query = "SELECT * FROM predictions WHERE user_id = ?"
    params = [user_id]

    if platform and platform != 'all':
        query += " AND platform = ?"
        params.append(platform.lower())

    if status and status != 'all':
        query += " AND status = ?"
        params.append(status.upper())

    query += " ORDER BY created_at DESC"

    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()
        results = []
        for r in rows:
            item = dict(r)
            item['input_features'] = json.loads(item['input_features_json'])
            item['explanation'] = json.loads(item['explanation_json'])
            results.append(item)
        return results


def get_prediction_by_id(prediction_id: int, user_id: int = None):
    """Retrieves a single prediction report with access control."""
    query = "SELECT * FROM predictions WHERE id = ?"
    params = [prediction_id]
    if user_id:
        query += " AND user_id = ?"
        params.append(user_id)

    with get_db() as conn:
        row = conn.execute(query, params).fetchone()
        if not row:
            return None
        item = dict(row)
        item['input_features'] = json.loads(item['input_features_json'])
        item['explanation'] = json.loads(item['explanation_json'])
        return item


def delete_prediction(prediction_id: int, user_id: int) -> bool:
    """Deletes a specific prediction entry belonging to user."""
    with get_db() as conn:
        cursor = conn.execute(
            "DELETE FROM predictions WHERE id = ? AND user_id = ?",
            (prediction_id, user_id)
        )
        conn.commit()
        return cursor.rowcount > 0


def get_dashboard_stats(user_id: int):
    """Calculates live analytics statistics for the user dashboard."""
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ?", (user_id,)).fetchone()[0]
        genuine = conn.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ? AND status = 'LIKELY GENUINE'", (user_id,)).fetchone()[0]
        fake = conn.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ? AND status = 'LIKELY FAKE'", (user_id,)).fetchone()[0]
        inconclusive = conn.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ? AND status = 'INCONCLUSIVE'", (user_id,)).fetchone()[0]

        # Platform counts
        platforms = {'instagram': 0, 'facebook': 0, 'linkedin': 0}
        rows = conn.execute(
            "SELECT platform, COUNT(*) as cnt FROM predictions WHERE user_id = ? GROUP BY platform",
            (user_id,)
        ).fetchall()
        for r in rows:
            if r['platform'] in platforms:
                platforms[r['platform']] = r['cnt']

        # Recent 5 predictions
        recent_rows = conn.execute(
            "SELECT id, platform, profile_identifier, status, confidence_score, created_at FROM predictions WHERE user_id = ? ORDER BY created_at DESC LIMIT 5",
            (user_id,)
        ).fetchall()
        recent = [dict(r) for r in recent_rows]

    return {
        'total_analyzed': total,
        'genuine_count': genuine,
        'fake_count': fake,
        'inconclusive_count': inconclusive,
        'platform_counts': platforms,
        'recent_analyses': recent
    }

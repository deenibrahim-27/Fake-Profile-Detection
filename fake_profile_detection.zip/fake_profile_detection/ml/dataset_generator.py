"""
Dataset Generator for Fake Profile Detection
Generates benchmark CSV datasets matching standard Kaggle schemas for:
1. Instagram Profile Dataset (data/instagram/instagram_profiles.csv)
2. Facebook Profile Dataset (data/facebook/facebook_profiles.csv)
3. LinkedIn Profile Dataset (data/linkedin/linkedin_profiles.csv)

Includes realistic feature distributions, missing values, and duplicate records
to test data cleaning and preprocessing pipelines.
"""

import os
import numpy as np
import pandas as pd

def generate_instagram_dataset(n_samples=1500, random_state=42):
    np.random.seed(random_state)
    n_genuine = int(n_samples * 0.55)
    n_fake = n_samples - n_genuine

    # --- Genuine Profiles ---
    g_profile_pic = np.random.choice([1, 0], size=n_genuine, p=[0.94, 0.06])
    g_nums_len_user = np.clip(np.random.beta(1.5, 8.0, size=n_genuine) * 0.4, 0.0, 1.0)
    g_fullname_words = np.random.choice([1, 2, 3, 4], size=n_genuine, p=[0.15, 0.65, 0.17, 0.03])
    g_nums_len_full = np.clip(np.random.beta(1.0, 10.0, size=n_genuine) * 0.2, 0.0, 1.0)
    g_name_eq_user = np.random.choice([0, 1], size=n_genuine, p=[0.88, 0.12])
    g_desc_len = np.random.normal(loc=72, scale=35, size=n_genuine).clip(0, 150).astype(int)
    g_external_url = np.random.choice([1, 0], size=n_genuine, p=[0.38, 0.62])
    g_private = np.random.choice([1, 0], size=n_genuine, p=[0.45, 0.55])
    g_posts = np.random.negative_binomial(5, 0.05, size=n_genuine).clip(2, 2500)
    g_followers = np.random.negative_binomial(10, 0.01, size=n_genuine).clip(25, 50000)
    g_follows = (g_followers * np.random.uniform(0.3, 1.8, size=n_genuine)).astype(int).clip(10, 4000)
    g_fake = np.zeros(n_genuine, dtype=int)

    # --- Fake Profiles ---
    f_profile_pic = np.random.choice([1, 0], size=n_fake, p=[0.42, 0.58])
    f_nums_len_user = np.clip(np.random.beta(4.0, 3.0, size=n_fake) * 0.85, 0.0, 1.0)
    f_fullname_words = np.random.choice([0, 1, 2, 3], size=n_fake, p=[0.32, 0.48, 0.18, 0.02])
    f_nums_len_full = np.clip(np.random.beta(3.0, 4.0, size=n_fake) * 0.7, 0.0, 1.0)
    f_name_eq_user = np.random.choice([0, 1], size=n_fake, p=[0.55, 0.45])
    f_desc_len = np.random.exponential(scale=18, size=n_fake).clip(0, 150).astype(int)
    f_external_url = np.random.choice([1, 0], size=n_fake, p=[0.68, 0.32])  # Spammers frequently link spam/phishing URLs
    f_private = np.random.choice([1, 0], size=n_fake, p=[0.18, 0.82])
    f_posts = np.random.negative_binomial(2, 0.3, size=n_fake).clip(0, 40)
    f_followers = np.random.negative_binomial(3, 0.04, size=n_fake).clip(0, 800)
    f_follows = np.random.negative_binomial(15, 0.015, size=n_fake).clip(200, 7500)  # Mass following
    f_fake = np.ones(n_fake, dtype=int)

    df_g = pd.DataFrame({
        'profile_pic': g_profile_pic,
        'nums_length_username': np.round(g_nums_len_user, 3),
        'fullname_words': g_fullname_words,
        'nums_length_fullname': np.round(g_nums_len_full, 3),
        'name_equals_username': g_name_eq_user,
        'description_length': g_desc_len,
        'external_url': g_external_url,
        'private': g_private,
        'posts': g_posts,
        'followers': g_followers,
        'follows': g_follows,
        'is_fake': g_fake
    })

    df_f = pd.DataFrame({
        'profile_pic': f_profile_pic,
        'nums_length_username': np.round(f_nums_len_user, 3),
        'fullname_words': f_fullname_words,
        'nums_length_fullname': np.round(f_nums_len_full, 3),
        'name_equals_username': f_name_eq_user,
        'description_length': f_desc_len,
        'external_url': f_external_url,
        'private': f_private,
        'posts': f_posts,
        'followers': f_followers,
        'follows': f_follows,
        'is_fake': f_fake
    })

    df = pd.concat([df_g, df_f], ignore_index=True)
    # Realistic borderline ambiguity (5% boundary overlap)
    flip_idx = np.random.choice(len(df), size=int(0.05 * len(df)), replace=False)
    df.loc[flip_idx, 'is_fake'] = 1 - df.loc[flip_idx, 'is_fake']
    df = df.sample(frac=1.0, random_state=random_state).reset_index(drop=True)

    # Introduce realistic missing values (5%) and duplicate rows (10 rows)
    nan_mask = np.random.rand(*df.shape) < 0.02
    for col in ['description_length', 'posts', 'nums_length_fullname']:
        df.loc[nan_mask[:, df.columns.get_loc(col)], col] = np.nan

    # Add duplicate rows
    dups = df.iloc[:12].copy()
    df = pd.concat([df, dups], ignore_index=True)
    return df


def generate_facebook_dataset(n_samples=1400, random_state=42):
    np.random.seed(random_state)
    n_genuine = int(n_samples * 0.52)
    n_fake = n_samples - n_genuine

    # Genuine Facebook profiles
    g_name_len = np.random.normal(loc=14, scale=3.5, size=n_genuine).clip(4, 30).astype(int)
    g_friends = np.random.negative_binomial(15, 0.04, size=n_genuine).clip(30, 2500)
    g_requests_sent = np.random.negative_binomial(5, 0.15, size=n_genuine).clip(0, 150)
    g_posts = np.random.negative_binomial(8, 0.06, size=n_genuine).clip(5, 800)
    g_likes = (g_posts * np.random.uniform(4.0, 35.0, size=n_genuine)).astype(int)
    g_age_days = np.random.uniform(180, 4200, size=n_genuine).astype(int)
    g_pfp = np.random.choice([1, 0], size=n_genuine, p=[0.96, 0.04])
    g_status = np.random.negative_binomial(4, 0.2, size=n_genuine).clip(0, 60)
    g_phone = np.random.choice([1, 0], size=n_genuine, p=[0.85, 0.15])
    g_fake = np.zeros(n_genuine, dtype=int)

    # Fake Facebook profiles
    f_name_len = np.random.normal(loc=11, scale=5.0, size=n_fake).clip(2, 35).astype(int)
    f_friends = np.random.negative_binomial(3, 0.1, size=n_fake).clip(0, 350)
    f_requests_sent = np.random.negative_binomial(20, 0.04, size=n_fake).clip(50, 1000)  # Aggressive friend request spam
    f_posts = np.random.negative_binomial(2, 0.4, size=n_fake).clip(0, 25)
    f_likes = (f_posts * np.random.uniform(0.1, 4.0, size=f_posts.shape[0])).astype(int)
    f_age_days = np.random.uniform(3, 220, size=n_fake).astype(int)  # Very young accounts
    f_pfp = np.random.choice([1, 0], size=n_fake, p=[0.48, 0.52])
    f_status = np.random.choice([0, 1, 2], size=n_fake, p=[0.75, 0.20, 0.05])
    f_phone = np.random.choice([1, 0], size=n_fake, p=[0.22, 0.78])
    f_fake = np.ones(n_fake, dtype=int)

    df_g = pd.DataFrame({
        'name_length': g_name_len,
        'friends_count': g_friends,
        'friend_requests_sent': g_requests_sent,
        'posts_count': g_posts,
        'likes_received': g_likes,
        'account_age_days': g_age_days,
        'profile_picture_present': g_pfp,
        'status_updates_recent': g_status,
        'mobile_number_linked': g_phone,
        'is_fake': g_fake
    })

    df_f = pd.DataFrame({
        'name_length': f_name_len,
        'friends_count': f_friends,
        'friend_requests_sent': f_requests_sent,
        'posts_count': f_posts,
        'likes_received': f_likes,
        'account_age_days': f_age_days,
        'profile_picture_present': f_pfp,
        'status_updates_recent': f_status,
        'mobile_number_linked': f_phone,
        'is_fake': f_fake
    })

    df = pd.concat([df_g, df_f], ignore_index=True)
    # Realistic borderline ambiguity (5% boundary overlap)
    flip_idx = np.random.choice(len(df), size=int(0.05 * len(df)), replace=False)
    df.loc[flip_idx, 'is_fake'] = 1 - df.loc[flip_idx, 'is_fake']
    df = df.sample(frac=1.0, random_state=random_state).reset_index(drop=True)

    # Missing values & duplicates
    nan_mask = np.random.rand(*df.shape) < 0.02
    for col in ['likes_received', 'account_age_days']:
        df.loc[nan_mask[:, df.columns.get_loc(col)], col] = np.nan

    dups = df.iloc[:10].copy()
    df = pd.concat([df, dups], ignore_index=True)
    return df


def generate_linkedin_dataset(n_samples=1350, random_state=42):
    np.random.seed(random_state)
    n_genuine = int(n_samples * 0.54)
    n_fake = n_samples - n_genuine

    # Genuine LinkedIn profiles
    g_headline_len = np.random.normal(loc=48, scale=18, size=n_genuine).clip(10, 120).astype(int)
    g_connections = np.random.negative_binomial(15, 0.035, size=n_genuine).clip(20, 800)
    g_experience = np.random.choice([1, 2, 3, 4, 5, 6, 7], size=n_genuine, p=[0.12, 0.22, 0.28, 0.20, 0.10, 0.05, 0.03])
    g_education = np.random.choice([1, 2, 3, 4], size=n_genuine, p=[0.45, 0.40, 0.12, 0.03])
    g_skills = np.random.negative_binomial(12, 0.45, size=n_genuine).clip(3, 45)
    g_pfp = np.random.choice([1, 0], size=n_genuine, p=[0.97, 0.03])
    g_summary_len = np.random.normal(loc=260, scale=120, size=n_genuine).clip(30, 800).astype(int)
    g_recs = np.random.negative_binomial(2, 0.4, size=n_genuine).clip(0, 15)
    g_current_co = np.random.choice([1, 0], size=n_genuine, p=[0.92, 0.08])
    g_fake = np.zeros(n_genuine, dtype=int)

    # Fake LinkedIn profiles
    f_headline_len = np.random.exponential(scale=16, size=n_fake).clip(0, 80).astype(int)
    f_connections = np.random.negative_binomial(2, 0.15, size=n_fake).clip(0, 80)
    f_experience = np.random.choice([0, 1, 2], size=n_fake, p=[0.72, 0.22, 0.06])
    f_education = np.random.choice([0, 1, 2], size=n_fake, p=[0.65, 0.30, 0.05])
    f_skills = np.random.choice([0, 1, 2, 3, 4], size=n_fake, p=[0.55, 0.25, 0.12, 0.05, 0.03])
    f_pfp = np.random.choice([1, 0], size=n_fake, p=[0.38, 0.62])
    f_summary_len = np.random.exponential(scale=20, size=n_fake).clip(0, 120).astype(int)
    f_recs = np.zeros(n_fake, dtype=int)
    f_current_co = np.random.choice([1, 0], size=n_fake, p=[0.24, 0.76])
    f_fake = np.ones(n_fake, dtype=int)

    df_g = pd.DataFrame({
        'headline_length': g_headline_len,
        'connections_count': g_connections,
        'experience_entries_count': g_experience,
        'education_entries_count': g_education,
        'skills_count': g_skills,
        'profile_picture_present': g_pfp,
        'summary_length': g_summary_len,
        'recommendations_count': g_recs,
        'has_current_company': g_current_co,
        'is_fake': g_fake
    })

    df_f = pd.DataFrame({
        'headline_length': f_headline_len,
        'connections_count': f_connections,
        'experience_entries_count': f_experience,
        'education_entries_count': f_education,
        'skills_count': f_skills,
        'profile_picture_present': f_pfp,
        'summary_length': f_summary_len,
        'recommendations_count': f_recs,
        'has_current_company': f_current_co,
        'is_fake': f_fake
    })

    df = pd.concat([df_g, df_f], ignore_index=True)
    # Realistic borderline ambiguity (5% boundary overlap)
    flip_idx = np.random.choice(len(df), size=int(0.05 * len(df)), replace=False)
    df.loc[flip_idx, 'is_fake'] = 1 - df.loc[flip_idx, 'is_fake']
    df = df.sample(frac=1.0, random_state=random_state).reset_index(drop=True)

    # Missing values & duplicates
    nan_mask = np.random.rand(*df.shape) < 0.02
    for col in ['summary_length', 'connections_count']:
        df.loc[nan_mask[:, df.columns.get_loc(col)], col] = np.nan

    dups = df.iloc[:8].copy()
    df = pd.concat([df, dups], ignore_index=True)
    return df


def seed_datasets(base_dir=None):
    if base_dir is None:
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    
    data_dir = os.path.join(base_dir, 'data')
    
    # 1. Instagram
    ig_path = os.path.join(data_dir, 'instagram', 'instagram_profiles.csv')
    df_ig = generate_instagram_dataset()
    df_ig.to_csv(ig_path, index=False)
    print(f"[+] Instagram dataset generated: {ig_path} ({df_ig.shape[0]} rows, {df_ig.shape[1]} cols)")

    # 2. Facebook
    fb_path = os.path.join(data_dir, 'facebook', 'facebook_profiles.csv')
    df_fb = generate_facebook_dataset()
    df_fb.to_csv(fb_path, index=False)
    print(f"[+] Facebook dataset generated: {fb_path} ({df_fb.shape[0]} rows, {df_fb.shape[1]} cols)")

    # 3. LinkedIn
    li_path = os.path.join(data_dir, 'linkedin', 'linkedin_profiles.csv')
    df_li = generate_linkedin_dataset()
    df_li.to_csv(li_path, index=False)
    print(f"[+] LinkedIn dataset generated: {li_path} ({df_li.shape[0]} rows, {df_li.shape[1]} cols)")


if __name__ == '__main__':
    seed_datasets()

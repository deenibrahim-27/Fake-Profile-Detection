"""
Prediction Service for Fake Profile Detection
Provides unified, high-performance prediction inference, cached model pipelines,
probabilistic calibration, explainability factors, and automated narrative explanations.
"""

import os
import json
import joblib
import pandas as pd
import numpy as np

from ml.data_preprocessing import (
    extract_instagram_features_from_raw,
    extract_facebook_features_from_raw,
    extract_linkedin_features_from_raw,
    get_platform_features
)

_MODEL_CACHE = {}
_METRICS_CACHE = {}


def get_base_dir():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))


def load_platform_assets(platform: str, base_dir=None):
    """Loads and caches platform model pipeline and evaluation metrics."""
    platform = platform.lower()
    if base_dir is None:
        base_dir = get_base_dir()

    if platform not in _MODEL_CACHE:
        model_path = os.path.join(base_dir, 'models', platform, 'model.joblib')
        metrics_path = os.path.join(base_dir, 'models', platform, 'metrics.json')

        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Trained model for {platform} not found at {model_path}.")

        _MODEL_CACHE[platform] = joblib.load(model_path)

        if os.path.exists(metrics_path):
            with open(metrics_path, 'r') as f:
                _METRICS_CACHE[platform] = json.load(f)
        else:
            _METRICS_CACHE[platform] = {}

    return _MODEL_CACHE[platform], _METRICS_CACHE[platform]


def explain_prediction(platform: str, raw_features_df: pd.DataFrame, fake_prob: float, metrics: dict) -> dict:
    """
    Computes explainability insights:
    - Identifies top contributing risk signals
    - Generates human-readable narrative bullet points
    """
    row = raw_features_df.iloc[0].to_dict()
    factors = []
    narratives = []

    if platform == 'instagram':
        # Analyze key Instagram indicators
        digits_ratio = row.get('nums_length_username', 0.0)
        has_pfp = row.get('profile_pic', 1)
        posts = row.get('posts', 0)
        followers = row.get('followers', 0)
        follows = row.get('follows', 0)
        desc_len = row.get('description_length', 0)
        name_eq = row.get('name_equals_username', 0)

        ratio = followers / (follows + 1)

        if digits_ratio > 0.35:
            factors.append({'factor': 'Username Digits Ratio', 'impact': 'High Risk', 'detail': f'{digits_ratio*100:.1f}% digits in username'})
            narratives.append(f"The username has a high proportion of numbers ({digits_ratio*100:.1f}%), a classic pattern among automated bot generators.")
        elif digits_ratio < 0.1:
            factors.append({'factor': 'Username Cleanliness', 'impact': 'Positive Indicator', 'detail': 'Low digit ratio in handle'})

        if has_pfp == 0:
            factors.append({'factor': 'Profile Picture', 'impact': 'High Risk', 'detail': 'Default avatar (no photo)'})
            narratives.append("No custom profile photo is uploaded; default avatars strongly correlate with disposable accounts.")
        else:
            factors.append({'factor': 'Profile Picture', 'impact': 'Positive Indicator', 'detail': 'Custom photo present'})

        if follows > 800 and followers < 100:
            factors.append({'factor': 'Mass Following Behavior', 'impact': 'High Risk', 'detail': f'Follows {follows:,} accounts with only {followers} followers'})
            narratives.append(f"Disproportionate follow-to-follower ratio ({follows:,} followed vs {followers:,} followers), indicative of mass-follow spam tactics.")
        elif posts >= 15 and followers > 200:
            factors.append({'factor': 'Activity & Engagement', 'impact': 'Positive Indicator', 'detail': f'{posts} posts with active audience'})

        if desc_len < 10:
            factors.append({'factor': 'Biography Completeness', 'impact': 'Moderate Risk', 'detail': 'Empty or sparse biography'})
            narratives.append("The account biography is empty or minimal, characteristic of hastily created accounts.")

        if name_eq == 1:
            factors.append({'factor': 'Name Redundancy', 'impact': 'Moderate Risk', 'detail': 'Full name identical to username handle'})

    elif platform == 'facebook':
        friends = row.get('friends_count', 0)
        requests = row.get('friend_requests_sent', 0)
        age_days = row.get('account_age_days', 0)
        has_pfp = row.get('profile_picture_present', 1)
        posts = row.get('posts_count', 0)
        phone_linked = row.get('mobile_number_linked', 1)

        if requests > 250 and friends < 100:
            factors.append({'factor': 'Aggressive Outbound Requests', 'impact': 'High Risk', 'detail': f'{requests:,} requests sent with only {friends} friends accepted'})
            narratives.append(f"Extremely high outbound friend requests ({requests:,}) compared to low confirmed friends ({friends}), indicative of social phishing or scrapers.")
        
        if age_days < 60:
            factors.append({'factor': 'Account Freshness', 'impact': 'High Risk', 'detail': f'Created only {age_days} days ago'})
            narratives.append(f"Account is recently created ({age_days} days old); new accounts represent a disproportionate volume of fraudulent activity.")
        elif age_days > 730:
            factors.append({'factor': 'Account Longevity', 'impact': 'Positive Indicator', 'detail': f'Active for {age_days // 365} years'})

        if has_pfp == 0:
            factors.append({'factor': 'Profile Picture', 'impact': 'High Risk', 'detail': 'Missing avatar'})
            narratives.append("Lack of an avatar or personal photo decreases account authenticity.")

        if phone_linked == 0:
            factors.append({'factor': 'Unverified Identity', 'impact': 'Moderate Risk', 'detail': 'No verified mobile number linked'})

    elif platform == 'linkedin':
        connections = row.get('connections_count', 0)
        experience = row.get('experience_entries_count', 0)
        education = row.get('education_entries_count', 0)
        skills = row.get('skills_count', 0)
        has_pfp = row.get('profile_picture_present', 1)
        headline_len = row.get('headline_length', 0)

        if experience == 0 and education == 0:
            factors.append({'factor': 'Zero Career History', 'impact': 'High Risk', 'detail': 'No experience or education listed'})
            narratives.append("The profile lists neither work experience nor education entries, an anomaly for authentic professional networks.")
        elif experience >= 3:
            factors.append({'factor': 'Career Trajectory', 'impact': 'Positive Indicator', 'detail': f'{experience} verifiable positions listed'})

        if connections < 15 and skills <= 1:
            factors.append({'factor': 'Minimal Network Endorsements', 'impact': 'High Risk', 'detail': f'{connections} connections and {skills} skills'})
            narratives.append("Low connection count combined with sparse skills indicates an unestablished or newly scripted profile.")

        if has_pfp == 0:
            factors.append({'factor': 'Professional Photo', 'impact': 'High Risk', 'detail': 'No professional headshot'})

        if headline_len < 10:
            factors.append({'factor': 'Headline Completeness', 'impact': 'Moderate Risk', 'detail': 'Brief or missing headline'})

    # If narratives are empty (e.g. balanced features)
    if not narratives:
        if fake_prob >= 0.5:
            narratives.append("Several minor statistical anomalies combine to indicate a pattern characteristic of automated or suspicious profiles.")
        else:
            narratives.append("Profile metadata aligns closely with legitimate user behavior patterns observed in historical training benchmarks.")

    return {
        'top_factors': factors,
        'narrative_bullets': narratives
    }


def predict_profile(platform: str, user_inputs: dict) -> dict:
    """
    Primary prediction API:
    1. Preprocesses user form values into schema-aligned feature vectors
    2. Runs inference through the trained scikit-learn pipeline
    3. Evaluates certainty and produces: LIKELY GENUINE, LIKELY FAKE, or INCONCLUSIVE
    4. Computes explainability insights and warnings
    """
    platform = platform.lower()
    pipeline, metrics = load_platform_assets(platform)

    # Extract features according to platform schema
    if platform == 'instagram':
        features_df = extract_instagram_features_from_raw(user_inputs)
        display_name = user_inputs.get('username', 'Target Instagram Profile')
    elif platform == 'facebook':
        features_df = extract_facebook_features_from_raw(user_inputs)
        display_name = user_inputs.get('profile_name', 'Target Facebook Profile')
    elif platform == 'linkedin':
        features_df = extract_linkedin_features_from_raw(user_inputs)
        display_name = user_inputs.get('profile_name', 'Target LinkedIn Profile')
    else:
        raise ValueError(f"Unsupported platform: {platform}")

    # Predict probabilities
    raw_pred = int(pipeline.predict(features_df)[0])
    probabilities = pipeline.predict_proba(features_df)[0]
    genuine_prob = round(float(probabilities[0]), 4)
    fake_prob = round(float(probabilities[1]), 4)

    # Determine tri-state status (Ambiguity zone 0.42 - 0.58 => INCONCLUSIVE)
    if 0.42 <= fake_prob <= 0.58:
        status = 'INCONCLUSIVE'
        status_label = 'Inconclusive / Ambiguous Evidence'
        status_badge = 'warning'
        confidence_score = round(max(genuine_prob, fake_prob) * 100, 1)
        summary_text = (
            "The available profile evidence is insufficient or contradictory to definitively classify this account. "
            "It displays a mixture of authentic and suspicious characteristics."
        )
    elif fake_prob > 0.58:
        status = 'LIKELY FAKE'
        status_label = 'Likely Fake / Suspicious'
        status_badge = 'danger'
        confidence_score = round(fake_prob * 100, 1)
        summary_text = (
            f"Based on algorithmic classification, this profile demonstrates behavioral markers strongly associated "
            f"with fake, automated, or spam accounts ({confidence_score}% model confidence)."
        )
    else:
        status = 'LIKELY GENUINE'
        status_label = 'Likely Genuine / Authentic'
        status_badge = 'success'
        confidence_score = round(genuine_prob * 100, 1)
        summary_text = (
            f"Based on algorithmic classification, this profile exhibits typical patterns of a legitimate, authentic "
            f"social media user ({confidence_score}% model confidence)."
        )

    # Explainability
    explanation = explain_prediction(platform, features_df, fake_prob, metrics)

    # Format extracted features for presentation
    feature_dict = features_df.iloc[0].to_dict()

    return {
        'platform': platform,
        'profile_identifier': display_name,
        'status': status,
        'status_label': status_label,
        'status_badge': status_badge,
        'predicted_class': raw_pred,
        'confidence_score': confidence_score,
        'fake_probability': round(fake_prob * 100, 2),
        'genuine_probability': round(genuine_prob * 100, 2),
        'summary_text': summary_text,
        'top_factors': explanation['top_factors'],
        'narrative_bullets': explanation['narrative_bullets'],
        'features_used': feature_dict,
        'model_name': metrics.get('best_algorithm', 'Supervised Classifier'),
        'model_accuracy': metrics.get('test_metrics', {}).get('accuracy', 0.95),
        'disclaimer': (
            "NOTICE & ETHICAL DISCLAIMER: This assessment is an automated estimate generated by a machine learning model "
            "trained on statistical profile indicators. It should be used solely as an investigative decision-support tool. "
            "It does NOT constitute absolute proof, forensic evidence, or an official determination by social media platforms."
        )
    }

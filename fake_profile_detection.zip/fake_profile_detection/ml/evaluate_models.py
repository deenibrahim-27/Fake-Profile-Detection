"""
Model Training & Evaluation Engine for Fake Profile Detection
Compares Logistic Regression, Decision Tree, Random Forest, and Gradient Boosting.
Performs Stratified 5-Fold Cross Validation on the training split, selects the optimal model,
evaluates on held-out test data, and persists pipeline + metrics to disk.
"""

import os
import sys

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import json
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)
from sklearn.pipeline import Pipeline

from ml.data_preprocessing import (
    clean_dataframe, build_preprocessor, get_platform_features
)


def get_candidate_models():
    """Returns candidate classification algorithms for comparison."""
    return {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Decision Tree': DecisionTreeClassifier(max_depth=5, random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42),
        'Gradient Boosting': GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, max_depth=4, random_state=42)
    }


def train_and_evaluate_platform(platform: str, base_dir=None):
    """
    Executes end-to-end training, cross-validation model selection,
    held-out testing, feature importance extraction, and artifact saving.
    """
    if base_dir is None:
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

    print(f"\n==========================================")
    print(f" TRAINING PIPELINE: {platform.upper()}")
    print(f"==========================================")

    data_path = os.path.join(base_dir, 'data', platform, f"{platform}_profiles.csv")
    if not os.path.exists(data_path):
        raise FileNotFoundError(f"Dataset not found at {data_path}. Run ml/dataset_generator.py first.")

    raw_df = pd.read_csv(data_path)
    print(f"[1] Loaded raw data: {raw_df.shape[0]} rows, {raw_df.shape[1]} columns.")

    # Clean & validate
    df = clean_dataframe(raw_df, platform)
    num_cols, bin_cols, target_col = get_platform_features(platform)
    feature_cols = num_cols + bin_cols

    # Ensure required columns exist
    missing_cols = [c for c in feature_cols + [target_col] if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns in {platform} dataset: {missing_cols}")

    X = df[feature_cols]
    y = df[target_col]

    print(f"[2] Cleaned data: {len(X)} records. Class balance: {dict(y.value_counts())}")

    # Stratified Train-Test Split (80/20)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    print(f"[3] Stratified split: {len(X_train)} train samples, {len(X_test)} test samples.")

    preprocessor = build_preprocessor(platform)

    # Model Comparison via 5-Fold Stratified Cross-Validation on X_train
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    candidate_models = get_candidate_models()
    comparison_results = {}
    best_model_name = None
    best_cv_score = -1.0

    print("\n[4] Running 5-Fold Stratified Cross-Validation...")
    for name, clf in candidate_models.items():
        candidate_pipe = Pipeline(steps=[
            ('preprocessor', preprocessor),
            ('classifier', clf)
        ])
        cv_f1 = cross_val_score(candidate_pipe, X_train, y_train, cv=cv, scoring='f1').mean()
        cv_roc = cross_val_score(candidate_pipe, X_train, y_train, cv=cv, scoring='roc_auc').mean()
        cv_acc = cross_val_score(candidate_pipe, X_train, y_train, cv=cv, scoring='accuracy').mean()

        comparison_results[name] = {
            'cv_f1_score': round(float(cv_f1), 4),
            'cv_roc_auc': round(float(cv_roc), 4),
            'cv_accuracy': round(float(cv_acc), 4)
        }
        print(f"    - {name:<20}: F1 = {cv_f1:.4f} | ROC-AUC = {cv_roc:.4f} | Accuracy = {cv_acc:.4f}")

        if cv_f1 > best_cv_score:
            best_cv_score = cv_f1
            best_model_name = name

    print(f"\n[5] Selected Best Algorithm: {best_model_name} (CV F1: {best_cv_score:.4f})")

    # Fit best model on complete training set
    best_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', candidate_models[best_model_name])
    ])
    best_pipeline.fit(X_train, y_train)

    # Evaluate on held-out test set
    y_pred = best_pipeline.predict(X_test)
    y_prob = best_pipeline.predict_proba(X_test)[:, 1] if hasattr(best_pipeline.named_steps['classifier'], "predict_proba") else None

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    roc_auc = roc_auc_score(y_test, y_prob) if y_prob is not None else None
    cm = confusion_matrix(y_test, y_pred).tolist()

    print(f"\n[6] Held-out Test Set Performance:")
    print(f"    - Accuracy : {acc:.4f}")
    print(f"    - Precision: {prec:.4f}")
    print(f"    - Recall   : {rec:.4f}")
    print(f"    - F1-Score : {f1:.4f}")
    if roc_auc:
        print(f"    - ROC-AUC  : {roc_auc:.4f}")
    print(f"    - Confusion Matrix:\n      {cm}")

    # Feature Importance Extraction
    feature_importances = {}
    clf_obj = best_pipeline.named_steps['classifier']
    if hasattr(clf_obj, 'feature_importances_'):
        raw_importances = clf_obj.feature_importances_
        for f, imp in zip(feature_cols, raw_importances):
            feature_importances[f] = round(float(imp), 4)
    elif hasattr(clf_obj, 'coef_'):
        raw_importances = np.abs(clf_obj.coef_[0])
        # Normalize
        total = np.sum(raw_importances) + 1e-9
        for f, imp in zip(feature_cols, raw_importances / total):
            feature_importances[f] = round(float(imp), 4)

    # Sort feature importances descending
    sorted_importances = dict(sorted(feature_importances.items(), key=lambda item: item[1], reverse=True))

    # Save artifacts
    save_dir = os.path.join(base_dir, 'models', platform)
    os.makedirs(save_dir, exist_ok=True)

    model_save_path = os.path.join(save_dir, 'model.joblib')
    joblib.dump(best_pipeline, model_save_path)
    print(f"\n[7] Saved trained model pipeline to: {model_save_path}")

    metrics_payload = {
        'platform': platform,
        'best_algorithm': best_model_name,
        'dataset_total_samples': int(len(df)),
        'training_samples': int(len(X_train)),
        'testing_samples': int(len(X_test)),
        'class_balance': {
            'genuine': int((y == 0).sum()),
            'fake': int((y == 1).sum())
        },
        'test_metrics': {
            'accuracy': round(float(acc), 4),
            'precision': round(float(prec), 4),
            'recall': round(float(rec), 4),
            'f1_score': round(float(f1), 4),
            'roc_auc': round(float(roc_auc), 4) if roc_auc else None
        },
        'confusion_matrix': {
            'true_negative': cm[0][0],
            'false_positive': cm[0][1],
            'false_negative': cm[1][0],
            'true_positive': cm[1][1]
        },
        'model_comparison': comparison_results,
        'feature_importances': sorted_importances,
        'features_used': feature_cols
    }

    metrics_save_path = os.path.join(save_dir, 'metrics.json')
    with open(metrics_save_path, 'w') as f:
        json.dump(metrics_payload, f, indent=4)
    print(f"[8] Saved evaluation metrics to: {metrics_save_path}")

    return metrics_payload


def train_all_platforms(base_dir=None):
    """Trains and saves models for all three social platforms."""
    results = {}
    for p in ['instagram', 'facebook', 'linkedin']:
        results[p] = train_and_evaluate_platform(p, base_dir)
    return results


if __name__ == '__main__':
    train_all_platforms()

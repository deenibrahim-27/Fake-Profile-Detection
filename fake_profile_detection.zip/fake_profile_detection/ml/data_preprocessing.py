"""
Data Preprocessing Module for Fake Profile Detection
Handles platform-specific schema parsing, cleaning, imputation, feature scaling,
and scikit-learn Pipeline construction to prevent data leakage.
"""

import pandas as pd
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer


# Schema definitions per platform
INSTAGRAM_NUMERICAL = [
    'nums_length_username',
    'fullname_words',
    'nums_length_fullname',
    'description_length',
    'posts',
    'followers',
    'follows'
]
INSTAGRAM_BINARY = [
    'profile_pic',
    'name_equals_username',
    'external_url',
    'private'
]
INSTAGRAM_TARGET = 'is_fake'

FACEBOOK_NUMERICAL = [
    'name_length',
    'friends_count',
    'friend_requests_sent',
    'posts_count',
    'likes_received',
    'account_age_days',
    'status_updates_recent'
]
FACEBOOK_BINARY = [
    'profile_picture_present',
    'mobile_number_linked'
]
FACEBOOK_TARGET = 'is_fake'

LINKEDIN_NUMERICAL = [
    'headline_length',
    'connections_count',
    'experience_entries_count',
    'education_entries_count',
    'skills_count',
    'summary_length',
    'recommendations_count'
]
LINKEDIN_BINARY = [
    'profile_picture_present',
    'has_current_company'
]
LINKEDIN_TARGET = 'is_fake'


def get_platform_features(platform: str):
    """Returns numerical and binary feature list for the given platform."""
    platform = platform.lower()
    if platform == 'instagram':
        return INSTAGRAM_NUMERICAL, INSTAGRAM_BINARY, INSTAGRAM_TARGET
    elif platform == 'facebook':
        return FACEBOOK_NUMERICAL, FACEBOOK_BINARY, FACEBOOK_TARGET
    elif platform == 'linkedin':
        return LINKEDIN_NUMERICAL, LINKEDIN_BINARY, LINKEDIN_TARGET
    else:
        raise ValueError(f"Unknown platform '{platform}'. Choose instagram, facebook, or linkedin.")


def clean_dataframe(df: pd.DataFrame, platform: str) -> pd.DataFrame:
    """
    Cleans raw DataFrame:
    - Normalizes column names (lower-case, underscores)
    - Removes duplicate rows
    - Maps target column name variants (e.g. 'fake' -> 'is_fake')
    - Validates presence of expected columns
    """
    df = df.copy()
    # Normalize headers
    df.columns = [c.strip().lower().replace(' ', '_').replace('/', '_').replace('#', '') for c in df.columns]

    # Map target column variants
    if 'fake' in df.columns and 'is_fake' not in df.columns:
        df.rename(columns={'fake': 'is_fake'}, inplace=True)
    if 'label' in df.columns and 'is_fake' not in df.columns:
        df.rename(columns={'label': 'is_fake'}, inplace=True)

    # Platform-specific column aliases
    if platform == 'instagram':
        aliases = {
            'fake': 'is_fake',
            'name==username': 'name_equals_username',
            'profile_pic_present': 'profile_pic',
            'bio_length': 'description_length'
        }
        for old_k, new_k in aliases.items():
            if old_k in df.columns and new_k not in df.columns:
                df.rename(columns={old_k: new_k}, inplace=True)
    elif platform == 'facebook':
        aliases = {
            'fake': 'is_fake',
            'pfp_present': 'profile_picture_present',
            'friends': 'friends_count',
            'posts': 'posts_count'
        }
        for old_k, new_k in aliases.items():
            if old_k in df.columns and new_k not in df.columns:
                df.rename(columns={old_k: new_k}, inplace=True)
    elif platform == 'linkedin':
        aliases = {
            'fake': 'is_fake',
            'connections': 'connections_count',
            'pfp_present': 'profile_picture_present'
        }
        for old_k, new_k in aliases.items():
            if old_k in df.columns and new_k not in df.columns:
                df.rename(columns={old_k: new_k}, inplace=True)

    # Remove exact duplicate rows
    initial_rows = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    dropped_dups = initial_rows - len(df)
    if dropped_dups > 0:
        print(f"[{platform.upper()}] Removed {dropped_dups} duplicate records.")

    # Target integrity check
    _, _, target_col = get_platform_features(platform)
    if target_col in df.columns:
        df = df.dropna(subset=[target_col])
        df[target_col] = df[target_col].astype(int)

    return df


def build_preprocessor(platform: str) -> ColumnTransformer:
    """
    Constructs a ColumnTransformer pipeline:
    - Median Imputer + StandardScaler for numerical features
    - Most Frequent Imputer for binary indicators
    """
    numerical_cols, binary_cols, _ = get_platform_features(platform)

    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    binary_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent'))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numerical_cols),
            ('bin', binary_transformer, binary_cols)
        ]
    )
    return preprocessor


def extract_instagram_features_from_raw(user_input: dict) -> pd.DataFrame:
    """
    Extracts numerical and behavioral features from raw Instagram user input.
    Computes:
    - Username length
    - Ratio of digits in username
    - Full name word count
    - Ratio of digits in full name
    - Whether name matches username
    - Bio length
    """
    username = str(user_input.get('username', '')).strip()
    fullname = str(user_input.get('fullname', '')).strip()
    bio = str(user_input.get('bio', '')).strip()

    # Digits in username
    u_len = max(len(username), 1)
    u_digits = sum(c.isdigit() for c in username)
    nums_length_username = round(u_digits / u_len, 4)

    # Fullname words and digits
    fn_words = len(fullname.split()) if fullname else 0
    fn_len = max(len(fullname), 1)
    fn_digits = sum(c.isdigit() for c in fullname)
    nums_length_fullname = round(fn_digits / fn_len, 4)

    # Name equals username check
    name_equals_username = 1 if username.lower() == fullname.lower() and len(username) > 0 else 0

    # Bio length
    desc_len = len(bio)

    # Boolean / counts
    profile_pic = int(user_input.get('profile_pic', 0))
    external_url = int(user_input.get('external_url', 0))
    private = int(user_input.get('private', 0))
    posts = int(user_input.get('posts', 0))
    followers = int(user_input.get('followers', 0))
    follows = int(user_input.get('follows', 0))

    row = {
        'profile_pic': profile_pic,
        'nums_length_username': nums_length_username,
        'fullname_words': fn_words,
        'nums_length_fullname': nums_length_fullname,
        'name_equals_username': name_equals_username,
        'description_length': desc_len,
        'external_url': external_url,
        'private': private,
        'posts': posts,
        'followers': followers,
        'follows': follows
    }
    return pd.DataFrame([row])


def extract_facebook_features_from_raw(user_input: dict) -> pd.DataFrame:
    """
    Extracts Facebook features from user form input.
    """
    profile_name = str(user_input.get('profile_name', '')).strip()
    name_len = len(profile_name)

    row = {
        'name_length': name_len,
        'friends_count': int(user_input.get('friends_count', 0)),
        'friend_requests_sent': int(user_input.get('friend_requests_sent', 0)),
        'posts_count': int(user_input.get('posts_count', 0)),
        'likes_received': int(user_input.get('likes_received', 0)),
        'account_age_days': int(user_input.get('account_age_days', 0)),
        'profile_picture_present': int(user_input.get('profile_picture_present', 0)),
        'status_updates_recent': int(user_input.get('status_updates_recent', 0)),
        'mobile_number_linked': int(user_input.get('mobile_number_linked', 0))
    }
    return pd.DataFrame([row])


def extract_linkedin_features_from_raw(user_input: dict) -> pd.DataFrame:
    """
    Extracts LinkedIn features from user form input.
    """
    headline = str(user_input.get('headline', '')).strip()
    summary = str(user_input.get('summary', '')).strip()

    row = {
        'headline_length': len(headline),
        'connections_count': int(user_input.get('connections_count', 0)),
        'experience_entries_count': int(user_input.get('experience_entries_count', 0)),
        'education_entries_count': int(user_input.get('education_entries_count', 0)),
        'skills_count': int(user_input.get('skills_count', 0)),
        'profile_picture_present': int(user_input.get('profile_picture_present', 0)),
        'summary_length': len(summary),
        'recommendations_count': int(user_input.get('recommendations_count', 0)),
        'has_current_company': int(user_input.get('has_current_company', 0))
    }
    return pd.DataFrame([row])

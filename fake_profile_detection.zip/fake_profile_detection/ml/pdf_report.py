"""
PDF Report Generator for Fake Profile Detection
Uses ReportLab to generate downloadable PDF analysis certificates and reports.
"""

import io
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


def generate_pdf_report(prediction_data: dict) -> io.BytesIO:
    """
    Constructs a PDF document in memory and returns a BytesIO buffer.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )

    styles = getSampleStyleSheet()
    story = []

    # Custom styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#0f172a'),
        alignment=0,
        spaceAfter=4
    )
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#64748b'),
        spaceAfter=15
    )
    section_heading = ParagraphStyle(
        'SectionHeading',
        parent=styles['Heading2'],
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#1e293b'),
        spaceBefore=12,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        'DocBody',
        parent=styles['Normal'],
        fontSize=9,
        leading=13,
        textColor=colors.HexColor('#334155')
    )
    disclaimer_style = ParagraphStyle(
        'Disclaimer',
        parent=styles['Normal'],
        fontSize=8,
        leading=11,
        textColor=colors.HexColor('#94a3b8')
    )

    # Document Header
    story.append(Paragraph("FAKE PROFILE DETECTION SYSTEM", title_style))
    story.append(Paragraph("Machine Learning Forensic Assessment Report | MCA Mini Project", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#3b82f6'), spaceAfter=15))

    # Profile & Result Summary Box
    status = prediction_data.get('status', 'INCONCLUSIVE')
    if status == 'LIKELY GENUINE':
        status_color = colors.HexColor('#10b981')
    elif status == 'LIKELY FAKE':
        status_color = colors.HexColor('#ef4444')
    else:
        status_color = colors.HexColor('#f59e0b')

    meta_table_data = [
        [
            Paragraph("<b>Target Profile:</b>", body_style),
            Paragraph(str(prediction_data.get('profile_identifier', 'Unknown')), body_style),
            Paragraph("<b>Platform:</b>", body_style),
            Paragraph(str(prediction_data.get('platform', '').capitalize()), body_style)
        ],
        [
            Paragraph("<b>Predicted Status:</b>", body_style),
            Paragraph(f"<font color='{status_color.hexval()}'><b>{status}</b></font>", body_style),
            Paragraph("<b>Model Confidence:</b>", body_style),
            Paragraph(f"{prediction_data.get('confidence_score', 0.0)}%", body_style)
        ],
        [
            Paragraph("<b>Fake Probability:</b>", body_style),
            Paragraph(f"{prediction_data.get('fake_probability', 0.0)}%", body_style),
            Paragraph("<b>Genuine Probability:</b>", body_style),
            Paragraph(f"{prediction_data.get('genuine_probability', 0.0)}%", body_style)
        ],
        [
            Paragraph("<b>Analysis Date:</b>", body_style),
            Paragraph(str(prediction_data.get('created_at', 'Just now')), body_style),
            Paragraph("<b>Report ID:</b>", body_style),
            Paragraph(f"REP-{prediction_data.get('id', 'NEW')}", body_style)
        ]
    ]

    summary_table = Table(meta_table_data, colWidths=[110, 150, 110, 150])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#e2e8f0')),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
        ('PADDING', (0, 0), (-1, -1), 6),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 12))

    # Narrative Explanation
    story.append(Paragraph("Model Decision Explanation", section_heading))
    explanation = prediction_data.get('explanation', {})
    bullets = explanation.get('narrative_bullets', [])
    if not bullets and 'summary_text' in prediction_data:
        bullets = [prediction_data['summary_text']]

    for bullet in bullets:
        story.append(Paragraph(f"• {bullet}", body_style))
        story.append(Spacer(1, 4))

    story.append(Spacer(1, 8))

    # Input Features Table
    story.append(Paragraph("Extracted Profile Features", section_heading))
    features = prediction_data.get('input_features', {})
    feat_data = [["Feature Parameter", "Evaluated Value"]]
    for k, v in features.items():
        feat_name = k.replace('_', ' ').title()
        feat_data.append([feat_name, str(v)])

    feat_table = Table(feat_data, colWidths=[280, 240])
    feat_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e293b')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 5),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#ffffff')),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f1f5f9')]),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(feat_table)
    story.append(Spacer(1, 14))

    # Disclaimer
    story.append(Paragraph("LEGAL & METHODOLOGICAL NOTICE", section_heading))
    disclaimer_text = (
        "This document is an academic forensic report generated using machine learning classification models. "
        "Predictions are probabilistic inferences based on extracted public profile parameters. This document does not "
        "constitute defamatory allegation, legal testimony, or official platform action. It is intended solely as an "
        "investigative decision-support tool."
    )
    story.append(Paragraph(disclaimer_text, disclaimer_style))

    doc.build(story)
    buffer.seek(0)
    return buffer

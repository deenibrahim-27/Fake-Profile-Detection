"""
Standalone Training Script for Instagram Fake Profile Detection
"""
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from ml.evaluate_models import train_and_evaluate_platform

if __name__ == '__main__':
    metrics = train_and_evaluate_platform('instagram')
    print("\nInstagram training complete. Test Accuracy:", metrics['test_metrics']['accuracy'])

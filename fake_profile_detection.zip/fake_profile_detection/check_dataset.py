
import pandas as pd

train = pd.read_csv("data/train.csv")
test = pd.read_csv("data/test.csv")

print("TRAINING DATA")
print("Shape:", train.shape)
print(train.head())

print("\nTESTING DATA")
print("Shape:", test.shape)
print(test.head())

print("\nTraining label counts:")
print(train["fake"].value_counts())

print("\nTesting label counts:")
print(test["fake"].value_counts())

print("\nMissing values:")
print(train.isnull().sum())
